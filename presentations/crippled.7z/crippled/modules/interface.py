#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -*- coding: binary -*-

# Crippleds CLI
# This file is part of Crippled.
# 2015 - GuerrillaWarfare - https://twitter.com/GuerrillaWF

import sys
import getopt
from modules.modem import Defaults
from modules.belkin import Belkin

class CrippledRuntimeError(RuntimeError):
    """Custom RuntimeError messages."""
    pass

class Crippled_CLI(object):

    def __init__(self):
        self.__Defaults     = Defaults()
        self.__belkin     = Belkin ()
        # Common variables
        self.__keys       = [] # store an algorithms key values.
        self.verbose      = True

    def __tell(self, text, sep=' ', end='\n', stream=sys.stdout, flush=False):
        if self.verbose or stream != sys.stdout:
            stream.write(text)
            if end is not None:
                stream.write(end)
            else:
                if sep is not None:
                    stream.write(sep)
            if flush or end is None:
                stream.flush()

    def boot(self):
        options = {}
        args, commands = getopt.getopt(sys.argv[1:], 'b:e:')
        args = dict(args)

        if len(commands) == 1 and commands[0] in self.commands:
            command = commands[0]
        else:
            # if no args or options exist, show the help.
            command = 'help'
            args = {}
        # if everything checks out. Run the desired command with the desired option(s)
        func = self.commands[command]

        req_params, opt_params = func.cli_options
        for param in req_params:
            if param not in ('-u',) and param not in args:
                raise CrippledRuntimeError("The command '%s' requires the " \
                                        "option '%s'. See 'help'." % \
                                        (command, param))
        for arg, value in args.iteritems():
            if arg in req_params or arg in opt_params:

                if arg == '-e':
                    options['essid'] = value

                elif arg == '-b':
                    options['bssid'] = str(value).upper() # May change depending on the situation, but generally accept it a lower-case MAC.

                    # Prevent messages from corrupting stdout
                    if value == '-':
                        self.verbose = False
            else:
                raise CrippledRuntimeError("The command '%s' ignores the " \
                                        "option '%s'." % (command, arg))

        self.__tell("\nCrippled | GuerrillaWarfare - https://github.com/GuerrillaWarfare")
        try:
            func(self, **options) # A wild TypeError appears from the tall grass.
            # Will have to fix this TypeError later. Not sure what's causing exactly.
        except TypeError:
            self.print_help() # For now call on the help, they always know what to do.

    def print_help(self):
        """Show this message again.
        """
        self.__tell('Usage    | Crippled [options] [command]'
            '\n'
            '\n Options:'
            '\n  -b        : Declare a BSSID'
            '\n  -e        : Declare an ESSID'
            '\n'
            '\n Commands:')
        m = max([len(command) for command in self.commands])
        for command, func in sorted(self.commands.items()):
            self.__tell('  %s%s : %s' % (command, \
                                        ' ' * (m - len(command)), \
                                        func.__doc__.split('\n')[0]))
    print_help.cli_options = ((), ())

    def __make_wordlist(self, nof, key):
        """Store generated keys in a file __dict__ file.
        """
        with open(nof, 'a+') as file:
            file.write(key + '\n')
            file.flush()

    def __mac_length(self, mac):
        """If the mac isn't a given size, alert the user, raise an error.
        """
        if len(mac) != 17:
            raise CrippledRuntimeError("\nERROR: That MAC address isn't the standard size.")

    def belkin_a(self, essid, bssid):
        """Returns all possible keys (if any) from the modules/belkin.py algorithm.
        """
        self.__mac_length(bssid) # Quick MAC length check.
        nof = essid + '.possible.keys'

        self.__tell("\nGenerating all possible keys for %s" % essid)

        for key in self.__belkin.possibilities(essid, bssid):
            self.__make_wordlist(nof, key) # immediately make the wordlist.
            self.__keys.append(key)
        self.__tell("Generated %d keys for %s" % (len(self.__keys), essid))
        self.__tell("The file %s has your generated keys.\n" % nof)

    belkin_a.cli_options = (('-e',), ('-b'))

    def modem_a(self, essid):
        """Returns all possible keys from the modules/modem.py algorithms.
        """
        # nof = name of file.
        #self.__mac_length(bssid) # Quick MAC length check.
        nof = essid + '.possible.keys'

        if 'DDW365' in essid:
            self.__tell("\nGenerating all possible keys for %s" % essid)
            for key in self.__Defaults.DDW365(essid):
                self.__keys.append(key)
                self.__make_wordlist(essid + '.possible.keys', key)
            self.__tell("Generated %d keys for %s" % (len(self.__keys), essid))
            self.__tell("The file %s has your generated keys.\n" % nof)

        elif 'SBG6580' in essid:
            self.__tell("\nGenerating all possible keys for %s" % essid)
            for key in self.__Defaults.SBG6580(essid):
                self.__keys.append(key)
                self.__make_wordlist(essid + '.possible.keys', key)
            self.__tell("Generated %d keys for %s" % (len(self.__keys), essid))
            self.__tell("The file %s has your generated keys.\n" % nof)

        elif 'U10C022' in essid:
            self.__tell("\nGenerating all possible keys for %s" % essid)
            for key in self.__Defaults.U10C022(essid):
                self.__keys.append(key)
                self.__make_wordlist(essid + '.possible.keys', key)
            self.__tell("Generated %d keys for %s" % (len(self.__keys), essid))
            self.__tell("The file %s has your generated keys.\n" % nof)

        elif 'TG852G' in essid:
            self.__tell("\nGenerating all possible keys for %s" % essid)
            for key in self.__Defaults.TG852G(essid):
                self.__keys.append(key)
                self.__make_wordlist(essid + '.possible.keys', key)
            self.__tell("Generated %d keys for %s" % (len(self.__keys), essid))
            self.__tell("The file %s has your generated keys.\n" % nof)

        elif 'DDW3611' in essid:
            self.__tell("\nGenerating all possible keys for %s" % essid)
            for key in self.__Defaults.DDW3611(essid):
                self.__keys.append(key)
                self.__make_wordlist(essid + '.possible.keys', key)
            self.__tell("Generated %d keys for %s" % (len(self.__keys), essid))
            self.__tell("The file %s has your generated keys.\n" % nof)

        elif 'DDW3612' in essid:
            self.__tell("\nGenerating all possible keys for %s" % essid)
            for key in self.__Defaults.DDW3612(essid):
                self.__keys.append(key)
                self.__make_wordlist(essid + '.possible.keys', key)
            self.__tell("Generated %d keys for %s" % (len(self.__keys), essid))
            self.__tell("The file %s has your generated keys.\n" % nof)

        elif 'DG860A' in essid:
            self.__tell("\nGenerating all possible keys for %s" % essid)
            for key in self.__Defaults.DG860A(essid):
                self.__keys.append(key)
                self.__make_wordlist(essid + '.possible.keys', key)
            self.__tell("Generated %d keys for %s" % (len(self.__keys), essid))
            self.__tell("The file %s has your generated keys.\n" % nof)

        elif 'TG862G' in essid:
            self.__tell("\nGenerating all possible keys for %s" % essid)
            for key in self.__Defaults.TG862G(essid):
                self.__keys.append(key)
                self.__make_wordlist(essid + '.possible.keys', key)
            self.__tell("Generated %d keys for %s" % (len(self.__keys), essid))
            self.__tell("The file %s has your generated keys.\n" % nof)

        elif 'TG1672G' in essid:
            self.__tell("\nGenerating all possible keys for %s" % essid)
            for key in self.__Defaults.TG1672G(essid):
                self.__keys.append(key)
                self.__make_wordlist(essid + '.possible.keys', key)
            self.__tell("Generated %d keys for %s" % (len(self.__keys), essid))
            self.__tell("The file %s has your generated keys.\n" % nof)

        elif 'DWG875' in essid:
            self.__tell("\nGenerating all possible keys for %s" % essid)
            for key in self.__Defaults.DWG875(essid):
                self.__keys.append(key)
                self.__make_wordlist(essid + '.possible.keys', key)
            self.__tell("Generated %d keys for %s" % (len(self.__keys), essid))
            self.__tell("The file %s has your generated keys.\n" % nof)

        else:
            raise CrippledRuntimeError("\nModem algorithm not yet supported.")

    modem_a.cli_options = (('-e',), ())

    commands = {'belkin': belkin_a,
                'modem':modem_a,
                'help':print_help # has to appear in options to trigger help when nothing is called.
                }
