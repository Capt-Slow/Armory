#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -*- coding: binary -*-

# This file part of Crippled.
# © 2015 - Present - GuerillaWarfare
# This is NOT fool-proof. None of these will work 100% of the time!

import sys
import string
import itertools

# Base character set for the default keyspace.
charset_1 = string.uppercase + string.digits # non-hex-based keys
charset_2 = "0123456789ABCDEF" # hex-based

#Four character keyspace permutations.
fcknh = itertools.permutations(charset_1 ,4) # non-hex-based
fckhb = itertools.permutations(charset_2 ,4) # hex-based

# Last 2 characters of the SSID
# l2COS = list(essid)[-2] + list(essid)[-1]

class Defaults(object):

    def __init__(self):
        self.__U10C022__keys  = []
        self.__SBG6580__keys  = []
        self.__DDW3611__keys  = []
        self.__DDW3612__keys  = []
        self.__DDW365__keys   = []
        self.__TG852G__keys   = []
        self.__DWG875__keys   = []
        self.__DG860A__keys   = []
        self.__TG862G__keys   = []
        self.__TG1672G__keys  = []
        self.__DVW3201B__keys = []

    def U10C022(self, essid):
        # Ubee/TWC

        l2COS = list(essid)[-2] + list(essid)[-1]

        for x in fcknh:
            keyspace_1 = x[0] + x[1] + x[2] + x[3] # non-hex-based
            self.__U10C022__keys.append("U10C022" + keyspace_1 + str(l2COS).upper())

        for y in fckhb:
            keyspace_2 = y[0] + y[1] + y[2] + y[3] # hex-based
            self.__U10C022__keys.append("U10C022" + keyspace_2 + str(l2COS).upper())
        return self.__U10C022__keys

    def DDW365(self, essid):
        # Ubee/TWC

        l2COS = list(essid)[-2] + list(essid)[-1]

        for x in fcknh:
            keyspace_1 = x[0] + x[1] + x[2] + x[3] # non-hex-based
            self.__DDW365__keys.append("DDW365" + keyspace_1 + str(l2COS).upper())

        for y in fckhb:
            keyspace_2 = y[0] + y[1] + y[2] + y[3] # hex-based
            self.__DDW365__keys.append("DDW365" + keyspace_2 + str(l2COS).upper())
        return self.__DDW365__keys

    def SBG6580(self, essid):
        # Motorola & Arris/Motorola

        l2COS = list(essid)[-2] + list(essid)[-1]

        for x in fcknh:
            keyspace_1 = x[0] + x[1] + x[2] + x[3] # non-hex-based
            self.__SBG6580__keys.append("SBG6580" + keyspace_1 + str(l2COS).upper())

        for y in fckhb:
            keyspace_2 = y[0] + y[1] + y[2] + y[3] # hex-based
            self.__SBG6580__keys.append("SBG6580" + keyspace_2 + str(l2COS).upper())
        return self.__SBG6580__keys

    def TG852G(self, essid):
        # Arris

        l2COS = list(essid)[-2] + list(essid)[-1]

        for x in fcknh:
            keyspace_1 = x[0] + x[1] + x[2] + x[3] # non-hex-based
            self.__TG852G__keys.append("TG852G" + keyspace_1 + str(l2COS).upper())

        for y in fckhb:
            keyspace_2 = y[0] + y[1] + y[2] + y[3] # hex-based
            self.__TG852G__keys.append("TG852G" + keyspace_2 + str(l2COS).upper())
        return self.__TG852G__keys

    def DDW3611(self, essid):
        # Ubee

        l2COS = list(essid)[-2] + list(essid)[-1]

        for x in fcknh:
            keyspace_1 = x[0] + x[1] + x[2] + x[3] # non-hex-based
            self.__DDW3611__keys.append("DDW3611" + keyspace_1 + str(l2COS).upper())

        for y in fckhb:
            keyspace_2 = y[0] + y[1] + y[2] + y[3] # hex-based
            self.__DDW3611__keys.append("DDW3611" + keyspace_2 + str(l2COS).upper())
        return self.__DDW3611__keys

    def DDW3612(self, essid):
        # Ubee

        l2COS = list(essid)[-2] + list(essid)[-1]

        for x in fcknh:
            keyspace_1 = x[0] + x[1] + x[2] + x[3] # non-hex-based
            self.__DDW3612__keys.append("DDW3612" + keyspace_1 + str(l2COS).upper())

        for y in fckhb:
            keyspace_2 = y[0] + y[1] + y[2] + y[3] # hex-based
            self.__DDW3612__keys.append("DDW3612" + keyspace_2 + str(l2COS).upper())
        return self.__DDW3612__keys

    def DWG875(self, essid):
        # Technicolor USA/TWC.

        l2COS = list(essid)[-2] + list(essid)[-1]

        for x in fcknh:
            keyspace_1 = x[0] + x[1] + x[2] + x[3] # non-hex-based
            self.__DWG875__keys.append("DWG875" + keyspace_1 + str(l2COS).upper())

        for y in fckhb:
            keyspace_2 = y[0] + y[1] + y[2] + y[3] # hex-based
            self.__DWG875__keys.append("DWG875" + keyspace_2 + str(l2COS).upper())
        return self.__DWG875__keys

    def DG860A(self, essid):
        # Arris/TWC

        l2COS = list(essid)[-2] + list(essid)[-1]

        for x in fcknh:
            keyspace_1 = x[0] + x[1] + x[2] + x[3] # non-hex-based
            self.__DG860A__keys.append("DG860A" + keyspace_1 + str(l2COS).upper())

        for y in fckhb:
            keyspace_2 = y[0] + y[1] + y[2] + y[3] # hex-based
            self.__DG860A__keys.append("DG860A" + keyspace_2 + str(l2COS).upper())
        return self.__DG860A__keys

    def TG862G(self, essid):
        # Arris

        l2COS = list(essid)[-2] + list(essid)[-1]

        for x in fcknh:
            keyspace_1 = x[0] + x[1] + x[2] + x[3] # non-hex-based
            self.__TG862G__keys.append("TG862G" + keyspace_1 + str(l2COS).upper())

        for y in fckhb:
            keyspace_2 = y[0] + y[1] + y[2] + y[3] # hex-based
            self.__TG862G__keys.append("TG862G" + keyspace_2 + str(l2COS).upper())
        return self.__TG862G__keys

    def TG1672G(self, essid):
        # Arris

        l2COS = list(essid)[-2] + list(essid)[-1]

        for x in fcknh:
            keyspace_1 = x[0] + x[1] + x[2] + x[3] # non-hex-based
            self.__TG1672G__keys.append("TG1672G" + keyspace_1 + str(l2COS).upper())

        for y in fckhb:
            keyspace_2 = y[0] + y[1] + y[2] + y[3] # hex-based
            self.__TG1672G__keys.append("TG1672G" + keyspace_2 + str(l2COS).upper())
        return self.__TG1672G__keys

    def DVW3201B(self, essid):
        # Arris

        l2COS = list(essid)[-2] + list(essid)[-1]

        for x in fcknh:
            keyspace_1 = x[0] + x[1] + x[2] + x[3] # non-hex-based
            self.__DVW3201B__keys.append("DVW3201B" + keyspace_1 + str(l2COS).upper())

        for y in fckhb:
            keyspace_2 = y[0] + y[1] + y[2] + y[3] # hex-based
            self.__DVW3201B__keys.append("DVW3201B" + keyspace_2 + str(l2COS).upper())
        return self.__DVW3201B__keys
