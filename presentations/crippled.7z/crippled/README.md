# Crippled
WPA/WPA2 access point default key generator.

###Donations:
- 17vorVqtJqbDaN6ZC6UGE7UwGC4QVmDNMh
